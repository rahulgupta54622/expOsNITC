# xsm2
The second revision to the eXperimental String Machine
